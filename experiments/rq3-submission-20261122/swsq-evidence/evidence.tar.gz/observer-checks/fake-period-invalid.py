import subprocess
rounds = 0
pattern = [[0], [1]]
command = ["sudo", "DBDS_Run=1", "/bin/false"]
def launch():
    subprocess.Popen(command).communicate()
launch()
for rounds in (1, 1, 2):
    try:
        launch()
    except Exception:
        launch()
