import subprocess
rounds = 0
pattern = [[0], [1]]
command = ["sudo", "DBDS_Run=1", "/bin/true"]
def launch():
    subprocess.Popen(command).communicate()
launch()
for rounds in range(1, 3):
    launch()
print("Round 3")
