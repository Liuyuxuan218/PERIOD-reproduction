#!/bin/sh
printf "HandleThreadStart 0\nHandleThreadStart 2\n"
if [ "${4:-0}" != 1 ]; then printf "HandleThreadExit 2\nHandleThreadExit 0\n"; fi
printf "PCT NUM STEPS: 12\nProgram EXIT\nSaving race DB\n"
if [ -n "${5:-}" ]; then printf "%s\n" "$5"; fi
exit "${3:-77}"
