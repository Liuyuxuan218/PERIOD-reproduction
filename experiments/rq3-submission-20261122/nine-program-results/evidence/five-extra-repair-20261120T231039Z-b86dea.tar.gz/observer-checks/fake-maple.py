import os, subprocess
for i in range(2):
    subprocess.Popen(['/workdir/rq3-five-extra-formal-5GfzyX/observer-checks/pin.sh', "-t", "/test/systematic_controller.so", os.environ.get("RQ3_FAKE_EXIT", "77"), os.environ.get("RQ3_FAKE_INCOMPLETE", "0"), os.environ.get("RQ3_FAKE_ERROR", "")]).communicate()
